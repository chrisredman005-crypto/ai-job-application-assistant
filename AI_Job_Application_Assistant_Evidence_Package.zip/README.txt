AI JOB APPLICATION ASSISTANT — PORTFOLIO EVIDENCE

01_Project_Brief.pdf
04_Version_1_Prompt.txt
05_Test_001_Mizuho.pdf
06_Version_2_Prompt.txt
07_Test_002_AI_Digital_Growth.pdf
08_Testing_and_Evaluation.pdf
09_Final_Portfolio_Case_Study.pdf

Version 2 has been designed and tested against two AI-related apprenticeship roles.

This is currently a prompt/workflow project, not a software application.
